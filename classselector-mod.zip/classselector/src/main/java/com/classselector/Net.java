package com.classselector;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.function.Supplier;

public class Net {
    private static final String V = "1";
    public static final SimpleChannel CH = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(ClassSelectorMod.MODID, "main"), () -> V, V::equals, V::equals);

    public static void register() {
        int i = 0;
        CH.registerMessage(i++, Sync.class, Sync::enc, Sync::dec, Sync::handle);
        CH.registerMessage(i++, Select.class, Select::enc, Select::dec, Select::handle);
        CH.registerMessage(i++, Save.class, Save::enc, Save::dec, Save::handle);
        CH.registerMessage(i++, Delete.class, Delete::enc, Delete::dec, Delete::handle);
        CH.registerMessage(i++, EditItems.class, EditItems::enc, EditItems::dec, EditItems::handle);
    }

    /** mode: 0 = só atualiza a lista, 1 = abre a tela (opcional), 2 = abre a tela obrigatória. */
    public static void sendSync(ServerPlayer p, int mode) {
        ClassData d = ClassData.get(p.server);
        ListTag l = new ListTag();
        for (ClassDef c : d.classes.values()) l.add(c.save());
        CompoundTag t = new CompoundTag();
        t.put("classes", l);
        CH.send(PacketDistributor.PLAYER.with(() -> p), new Sync(mode, p.hasPermissions(2), t));
    }

    public static void syncAll(MinecraftServer s) {
        for (ServerPlayer p : s.getPlayerList().getPlayers()) sendSync(p, 0);
    }

    // ---------- servidor -> cliente ----------
    public record Sync(int mode, boolean op, CompoundTag data) {
        static void enc(Sync m, FriendlyByteBuf b) { b.writeVarInt(m.mode); b.writeBoolean(m.op); b.writeNbt(m.data); }
        static Sync dec(FriendlyByteBuf b) { return new Sync(b.readVarInt(), b.readBoolean(), b.readNbt()); }
        static void handle(Sync m, Supplier<NetworkEvent.Context> c) {
            c.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                    () -> () -> ClientHooks.sync(m.mode, m.op, m.data)));
            c.get().setPacketHandled(true);
        }
    }

    // ---------- cliente -> servidor ----------
    public record Select(String id) {
        static void enc(Select m, FriendlyByteBuf b) { b.writeUtf(m.id, 64); }
        static Select dec(FriendlyByteBuf b) { return new Select(b.readUtf(64)); }
        static void handle(Select m, Supplier<NetworkEvent.Context> c) {
            c.get().enqueueWork(() -> {
                ServerPlayer p = c.get().getSender();
                if (p == null) return;
                ClassDef def = ClassData.get(p.server).classes.get(m.id);
                if (def == null) return;
                boolean chosen = !p.getPersistentData().getString(ClassSelectorMod.KEY).isEmpty();
                if (chosen && !p.hasPermissions(2)) return; // só OP pode trocar de classe
                p.getPersistentData().putString(ClassSelectorMod.KEY, def.id);
                for (ItemStack s : def.items) {
                    ItemStack copy = s.copy();
                    if (!p.getInventory().add(copy)) p.drop(copy, false);
                }
            });
            c.get().setPacketHandled(true);
        }
    }

    public record Save(CompoundTag def) {
        static void enc(Save m, FriendlyByteBuf b) { b.writeNbt(m.def); }
        static Save dec(FriendlyByteBuf b) { return new Save(b.readNbt()); }
        static void handle(Save m, Supplier<NetworkEvent.Context> c) {
            c.get().enqueueWork(() -> {
                ServerPlayer p = c.get().getSender();
                if (p == null || !p.hasPermissions(2)) return;
                ClassDef in = ClassDef.load(m.def);
                in.id = ClassDef.sanitize(in.id);
                if (in.id.isEmpty() || in.name.isBlank()) return;
                if (in.name.length() > 40) in.name = in.name.substring(0, 40);
                if (in.description.length() > 300) in.description = in.description.substring(0, 300);
                ClassData data = ClassData.get(p.server);
                ClassDef old = data.classes.get(in.id);
                in.items = old != null ? old.items : new java.util.ArrayList<>(); // itens só mudam pelo baú
                data.classes.put(in.id, in);
                data.setDirty();
                syncAll(p.server);
            });
            c.get().setPacketHandled(true);
        }
    }

    public record Delete(String id) {
        static void enc(Delete m, FriendlyByteBuf b) { b.writeUtf(m.id, 64); }
        static Delete dec(FriendlyByteBuf b) { return new Delete(b.readUtf(64)); }
        static void handle(Delete m, Supplier<NetworkEvent.Context> c) {
            c.get().enqueueWork(() -> {
                ServerPlayer p = c.get().getSender();
                if (p == null || !p.hasPermissions(2)) return;
                ClassData data = ClassData.get(p.server);
                if (data.classes.remove(m.id) != null) {
                    data.setDirty();
                    syncAll(p.server);
                }
            });
            c.get().setPacketHandled(true);
        }
    }

    public record EditItems(String id) {
        static void enc(EditItems m, FriendlyByteBuf b) { b.writeUtf(m.id, 64); }
        static EditItems dec(FriendlyByteBuf b) { return new EditItems(b.readUtf(64)); }
        static void handle(EditItems m, Supplier<NetworkEvent.Context> c) {
            c.get().enqueueWork(() -> {
                ServerPlayer p = c.get().getSender();
                if (p == null || !p.hasPermissions(2)) return;
                ClassDef def = ClassData.get(p.server).classes.get(m.id);
                if (def != null) ClassItemsMenu.open(p, def);
            });
            c.get().setPacketHandled(true);
        }
    }
}
