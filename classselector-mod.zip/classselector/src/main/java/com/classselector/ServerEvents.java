package com.classselector;

import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ClassSelectorMod.MODID)
public class ServerEvents {

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        boolean chosen = !p.getPersistentData().getString(ClassSelectorMod.KEY).isEmpty();
        boolean any = !ClassData.get(p.server).classes.isEmpty();
        Net.sendSync(p, (!chosen && any) ? 2 : 0);
    }

    /** Mantém a classe escolhida depois de morrer. */
    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone e) {
        String s = e.getOriginal().getPersistentData().getString(ClassSelectorMod.KEY);
        if (!s.isEmpty()) e.getEntity().getPersistentData().putString(ClassSelectorMod.KEY, s);
    }

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("classes")
                .requires(s -> s.hasPermission(2))
                // /classes -> abre a tela (com os botões de OP)
                .executes(c -> {
                    Net.sendSync(c.getSource().getPlayerOrException(), 1);
                    return 1;
                })
                // /classes reset <jogador> -> jogador escolhe a classe de novo
                .then(Commands.literal("reset").then(Commands.argument("player", EntityArgument.player())
                        .executes(c -> {
                            ServerPlayer t = EntityArgument.getPlayer(c, "player");
                            t.getPersistentData().remove(ClassSelectorMod.KEY);
                            Net.sendSync(t, 2);
                            c.getSource().sendSuccess(() -> Component.literal(
                                    "Classe de " + t.getName().getString() + " resetada."), true);
                            return 1;
                        }))));
    }
}
