package com.classselector;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.List;

/** Tela de seleção de classes (estilo da tela de conquistas). */
public class ClassSelectScreen extends Screen {
    private static final int W = 330, H = 210, TREE_W = 170, VISIBLE = 5, ROW_H = 34;

    private final boolean forced;
    private int left, top, scroll;
    private String selected;
    private Button choose;
    private ItemStack hoverStack = ItemStack.EMPTY;

    public ClassSelectScreen(boolean forced) {
        super(Component.literal("Classes"));
        this.forced = forced;
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
        choose = addRenderableWidget(Button.builder(Component.literal("Selecionar"), b -> {
            if (selected != null && sel() != null) {
                Net.CH.sendToServer(new Net.Select(selected));
                minecraft.setScreen(null);
            }
        }).bounds(left + W - 124, top + H - 28, 116, 20).build());

        if (ClientHooks.op) {
            addRenderableWidget(Button.builder(Component.literal("+ Nova"),
                    b -> minecraft.setScreen(new ClassEditScreen(this, null)))
                    .bounds(left + 8, top + H - 28, 60, 20).build());
            addRenderableWidget(Button.builder(Component.literal("Editar"), b -> {
                ClassDef c = sel();
                if (c != null) minecraft.setScreen(new ClassEditScreen(this, c));
            }).bounds(left + 72, top + H - 28, 60, 20).build());
        }
    }

    private ClassDef sel() {
        for (ClassDef c : ClientHooks.classes) if (c.id.equals(selected)) return c;
        return null;
    }

    @Override
    public boolean shouldCloseOnEsc() { return !forced; }

    @Override
    public boolean isPauseScreen() { return false; }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        hoverStack = ItemStack.EMPTY;

        g.fill(left - 2, top - 2, left + W + 2, top + H + 2, 0xFF000000);
        g.fill(left, top, left + W, top + H, 0xFFC6C6C6);
        g.drawString(font, "Classes", left + 8, top + 6, 0x404040, false);

        int tx = left + 6, ty = top + 20, th = H - 52;
        g.fill(tx, ty, tx + TREE_W, ty + th, 0xFF707070);
        g.fill(left + TREE_W + 10, ty, left + W - 6, ty + th, 0xFF181818);

        List<ClassDef> cl = ClientHooks.classes;
        scroll = Mth.clamp(scroll, 0, Math.max(0, cl.size() - VISIBLE));
        int n = Math.min(VISIBLE, cl.size() - scroll);

        // raiz
        int rx = tx + 8, ry = ty + th / 2 - 12;
        g.fill(rx - 1, ry - 1, rx + 25, ry + 25, 0xFFB8860B);
        g.fill(rx, ry, rx + 24, ry + 24, 0xFFE0A030);
        g.renderItem(new ItemStack(Items.GOLDEN_HELMET), rx + 4, ry + 4);

        if (n > 0) {
            int line = 0xFFE8E8E8, vx = tx + 44, nx = tx + 60;
            int firstCy = ty + 6 + 12, lastCy = ty + 6 + (n - 1) * ROW_H + 12, rootCy = ry + 12;
            g.hLine(rx + 24, vx, rootCy, line);
            g.vLine(vx, Math.min(firstCy, rootCy), Math.max(lastCy, rootCy), line);
            for (int i = 0; i < n; i++) {
                ClassDef c = cl.get(scroll + i);
                int y = ty + 6 + i * ROW_H, cy = y + 12;
                boolean isSel = c.id.equals(selected);
                g.hLine(vx, nx, cy, line);
                g.fill(nx - 1, y - 1, nx + 25, y + 25, isSel ? 0xFFFFC040 : 0xFF000000);
                g.fill(nx, y, nx + 24, y + 24, 0xFF8B8B8B);
                g.renderItem(c.iconStack(), nx + 4, y + 4);
                g.drawString(font, font.plainSubstrByWidth(c.name, 76), nx + 30, cy - 4,
                        isSel ? 0xFFFFC040 : 0xFFFFFF, true);
            }
        }

        // detalhes
        ClassDef c = sel();
        int dx = left + TREE_W + 16, dy = ty + 6, dw = W - TREE_W - 28;
        if (c == null) {
            g.drawString(font, "Escolha uma classe", dx, dy, 0xFF9A9A9A, false);
        } else {
            g.renderItem(c.iconStack(), dx, dy);
            g.drawString(font, font.plainSubstrByWidth(c.name, dw - 24), dx + 22, dy + 4, 0xFFFFFF, false);
            int y = dy + 24, lines = 0;
            for (FormattedCharSequence l : font.split(Component.literal(c.description), dw)) {
                if (lines++ >= 4) break;
                g.drawString(font, l, dx, y, 0xFFDDDDDD, false);
                y += 10;
            }
            y += 4;
            if (!c.abilities.isEmpty()) {
                g.drawString(font, "Habilidades:", dx, y, 0xFFAAAAAA, false);
                y += 10;
                for (int i = 0; i < Math.min(4, c.abilities.size()); i++) {
                    g.drawString(font, "- " + font.plainSubstrByWidth(c.abilities.get(i), dw - 10), dx, y, 0xFFDDDDDD, false);
                    y += 10;
                }
                y += 4;
            }
            if (!c.items.isEmpty()) {
                g.drawString(font, "Itens:", dx, y, 0xFFAAAAAA, false);
                y += 11;
                for (int i = 0; i < Math.min(7, c.items.size()); i++) {
                    int ix = dx + i * 18;
                    ItemStack s = c.items.get(i);
                    g.renderItem(s, ix, y);
                    g.renderItemDecorations(font, s, ix, y);
                    if (mx >= ix && mx < ix + 16 && my >= y && my < y + 16) hoverStack = s;
                }
            }
        }

        choose.active = c != null;
        super.render(g, mx, my, pt);
        if (!hoverStack.isEmpty()) g.renderTooltip(font, hoverStack, mx, my);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        List<ClassDef> cl = ClientHooks.classes;
        int ty = top + 20, nx = left + 6 + 60;
        int n = Math.min(VISIBLE, cl.size() - scroll);
        for (int i = 0; i < n; i++) {
            int y = ty + 6 + i * ROW_H;
            if (mx >= nx && mx < nx + 100 && my >= y && my < y + 24) {
                selected = cl.get(scroll + i).id;
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        scroll -= (int) Math.signum(delta);
        return true;
    }
}
