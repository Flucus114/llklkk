package com.classselector;

import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;

import java.util.ArrayList;
import java.util.List;

public class ClientHooks {
    public static final List<ClassDef> classes = new ArrayList<>();
    public static boolean op = false;

    public static void sync(int mode, boolean isOp, CompoundTag data) {
        classes.clear();
        for (Tag t : data.getList("classes", Tag.TAG_COMPOUND)) classes.add(ClassDef.load((CompoundTag) t));
        op = isOp;
        if (mode > 0) Minecraft.getInstance().setScreen(new ClassSelectScreen(mode == 2));
    }
}
